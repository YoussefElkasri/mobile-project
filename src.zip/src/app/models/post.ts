export interface Post {
    id: string;
    name: string;
    description: string;
}
